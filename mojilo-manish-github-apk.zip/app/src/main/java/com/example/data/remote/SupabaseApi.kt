package com.example.data.remote

import com.example.data.models.CompletedTestStatus
import com.example.data.models.QuestionItem
import com.example.data.models.TestItem
import com.example.data.models.UserProfile
import retrofit2.Response
import retrofit2.http.*

interface SupabaseApi {

    // PROFILES
    @GET("rest/v1/profiles?select=*")
    suspend fun getProfiles(): Response<List<UserProfile>>

    @GET("rest/v1/profiles?select=*")
    suspend fun getProfileByMobile(
        @Query("mobile_number") mobileEqFilter: String // e.g. "eq.9876543210"
    ): Response<List<UserProfile>>

    @POST("rest/v1/profiles")
    suspend fun createProfile(
        @Body profile: UserProfile
    ): Response<List<UserProfile>>

    @PATCH("rest/v1/profiles")
    suspend fun updateProfile(
        @Query("id") idEqFilter: String, // e.g. "eq.uuid"
        @Body updates: Map<String, @JvmSuppressWildcards Any?>
    ): Response<List<UserProfile>>

    @DELETE("rest/v1/profiles")
    suspend fun deleteProfile(
        @Query("id") idEqFilter: String
    ): Response<Unit>

    // TESTS
    @GET("rest/v1/tests?select=*&order=created_at.desc")
    suspend fun getTests(): Response<List<TestItem>>

    @POST("rest/v1/tests")
    suspend fun createTest(
        @Body test: TestItem
    ): Response<List<TestItem>>

    @PATCH("rest/v1/tests")
    suspend fun updateTest(
        @Query("id") idEqFilter: String,
        @Body updates: Map<String, @JvmSuppressWildcards Any?>
    ): Response<List<TestItem>>

    @DELETE("rest/v1/tests")
    suspend fun deleteTest(
        @Query("id") idEqFilter: String
    ): Response<Unit>

    // QUESTIONS
    @GET("rest/v1/questions?select=*")
    suspend fun getQuestionsForTest(
        @Query("test_id") testIdEqFilter: String
    ): Response<List<QuestionItem>>

    @POST("rest/v1/questions")
    suspend fun createQuestion(
        @Body question: QuestionItem
    ): Response<List<QuestionItem>>

    @PATCH("rest/v1/questions")
    suspend fun updateQuestion(
        @Query("id") idEqFilter: String,
        @Body updates: Map<String, @JvmSuppressWildcards Any?>
    ): Response<List<QuestionItem>>

    @DELETE("rest/v1/questions")
    suspend fun deleteQuestion(
        @Query("id") idEqFilter: String
    ): Response<Unit>

    // COMPLETED TESTS (ONLY student_id & test_id stored)
    @GET("rest/v1/completed_tests?select=*")
    suspend fun getCompletedTestsForStudent(
        @Query("student_id") studentIdEqFilter: String
    ): Response<List<CompletedTestStatus>>

    @POST("rest/v1/completed_tests")
    suspend fun recordTestCompletion(
        @Body completedTest: CompletedTestStatus
    ): Response<List<CompletedTestStatus>>
}
