package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.Screen
import com.example.ui.screens.*
import com.example.ui.theme.MojiloManishTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MojiloManishTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun AppNavigation(viewModel: MainViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // Overlay Score Result Dialog when a test is submitted
    if (uiState.activeScoreResult != null) {
        ScoreResultDialog(
            scoreResult = uiState.activeScoreResult!!,
            onDismiss = { viewModel.dismissScoreResultDialog() }
        )
    }

    Crossfade(
        targetState = uiState.currentScreen,
        animationSpec = tween(durationMillis = 350),
        label = "screen_crossfade"
    ) { screen ->
        when (screen) {
            is Screen.Splash -> {
                SplashScreen(
                    onTimeout = { viewModel.onSplashFinished() }
                )
            }
            is Screen.Login -> {
                LoginScreen(
                    uiState = uiState,
                    onLoginClick = { mobile, pass -> viewModel.login(mobile, pass) },
                    onClearError = { viewModel.clearError() },
                    onSaveSupabaseConfig = { url, key -> viewModel.updateSupabaseConfig(url, key) }
                )
            }
            is Screen.StudentDashboard -> {
                StudentDashboardScreen(
                    user = uiState.currentUser,
                    tests = uiState.studentTests,
                    isLoading = uiState.isLoading,
                    onStartTest = { test -> viewModel.startTest(test) },
                    onRefresh = {
                        uiState.currentUser?.let { viewModel.loadStudentData(it.id) }
                    },
                    onLogout = { viewModel.logout() }
                )
            }
            is Screen.TakeTest -> {
                TakeTestScreen(
                    test = screen.test,
                    questions = uiState.testQuestions,
                    currentQuestionIndex = uiState.currentQuestionIndex,
                    selectedAnswers = uiState.selectedAnswers,
                    onSelectOption = { qId, optIdx -> viewModel.selectOption(qId, optIdx) },
                    onGoToQuestion = { idx -> viewModel.goToQuestion(idx) },
                    onSubmitTest = { viewModel.submitTest() },
                    onBack = { viewModel.dismissScoreResultDialog() }
                )
            }
            is Screen.AdminDashboard -> {
                AdminDashboardScreen(
                    user = uiState.currentUser,
                    students = uiState.adminStudents,
                    tests = uiState.adminTests,
                    selectedTestForQuestions = uiState.adminSelectedTestForQuestions,
                    questionsForTest = uiState.adminQuestionsForTest,
                    isLoading = uiState.isLoading,
                    onAddStudent = { name, mobile, pass -> viewModel.adminAddStudent(name, mobile, pass) },
                    onUpdateStudent = { id, name, mobile, pass, isActive ->
                        viewModel.adminUpdateStudent(id, name, mobile, pass, isActive)
                    },
                    onDeleteStudent = { id -> viewModel.adminDeleteStudent(id) },
                    onResetDeviceLock = { id -> viewModel.adminResetStudentDeviceLock(id) },
                    onCreateTest = { title, isActive, reattempt ->
                        viewModel.adminCreateTest(title, isActive, reattempt)
                    },
                    onUpdateTest = { id, title, isActive, reattempt ->
                        viewModel.adminUpdateTest(id, title, isActive, reattempt)
                    },
                    onDeleteTest = { id -> viewModel.adminDeleteTest(id) },
                    onSelectTestForQuestions = { test -> viewModel.adminSelectTestForQuestions(test) },
                    onAddQuestion = { testId, qText, options, correctIdx, marks ->
                        viewModel.adminAddQuestion(testId, qText, options, correctIdx, marks)
                    },
                    onUpdateQuestion = { id, testId, qText, options, correctIdx, marks ->
                        viewModel.adminUpdateQuestion(id, testId, qText, options, correctIdx, marks)
                    },
                    onDeleteQuestion = { id, testId -> viewModel.adminDeleteQuestion(id, testId) },
                    onLogout = { viewModel.logout() }
                )
            }
        }
    }
}
