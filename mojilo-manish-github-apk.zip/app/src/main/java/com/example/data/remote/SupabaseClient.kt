package com.example.data.remote

import android.content.Context
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

object SupabaseClient {

    private var currentApi: SupabaseApi? = null
    private var currentBaseUrl: String? = null
    private var currentKey: String? = null

    fun getApi(context: Context): SupabaseApi {
        val baseUrl = SupabaseConfig.getSupabaseUrl(context).let {
            if (it.endsWith("/")) it else "$it/"
        }
        val apiKey = SupabaseConfig.getSupabaseAnonKey(context)

        if (currentApi != null && currentBaseUrl == baseUrl && currentKey == apiKey) {
            return currentApi!!
        }

        val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

        val headerInterceptor = Interceptor { chain ->
            val request = chain.request().newBuilder()
                .header("apikey", apiKey)
                .header("Authorization", "Bearer $apiKey")
                .header("Content-Type", "application/json")
                .header("Prefer", "return=representation")
                .build()
            chain.proceed(request)
        }

        val okHttpClient = OkHttpClient.Builder()
            .addInterceptor(headerInterceptor)
            .addInterceptor(loggingInterceptor)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()

        val moshi = Moshi.Builder()
            .add(KotlinJsonAdapterFactory())
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()

        val api = retrofit.create(SupabaseApi::class.java)
        currentApi = api
        currentBaseUrl = baseUrl
        currentKey = apiKey

        return api
    }

    fun resetClient() {
        currentApi = null
        currentBaseUrl = null
        currentKey = null
    }
}
