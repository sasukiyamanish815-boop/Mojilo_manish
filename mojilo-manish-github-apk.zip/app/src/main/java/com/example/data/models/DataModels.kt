package com.example.data.models

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class UserProfile(
    @Json(name = "id") val id: String = "",
    @Json(name = "mobile_number") val mobileNumber: String = "",
    @Json(name = "name") val name: String = "",
    @Json(name = "password") val password: String = "",
    @Json(name = "role") val role: String = "student", // "admin" or "student"
    @Json(name = "is_active") val isActive: Boolean = true,
    @Json(name = "active_device_id") val activeDeviceId: String? = null,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class TestItem(
    @Json(name = "id") val id: String = "",
    @Json(name = "title") val title: String = "",
    @Json(name = "is_active") val isActive: Boolean = true,
    @Json(name = "reattempt_allowed") val reattemptAllowed: Boolean = false,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class QuestionItem(
    @Json(name = "id") val id: String = "",
    @Json(name = "test_id") val testId: String = "",
    @Json(name = "question_text") val questionText: String = "",
    @Json(name = "options") val options: List<String> = emptyList(),
    @Json(name = "correct_option_index") val correctOptionIndex: Int = 0,
    @Json(name = "marks") val marks: Int = 1
)

// CompletedTest record in DB contains strictly ONLY student_id, test_id, and completed_at.
// NO marks, NO answers, NO scores stored here!
@JsonClass(generateAdapter = true)
data class CompletedTestStatus(
    @Json(name = "id") val id: String? = null,
    @Json(name = "student_id") val studentId: String = "",
    @Json(name = "test_id") val testId: String = "",
    @Json(name = "completed_at") val completedAt: String? = null
)

data class TestWithStatus(
    val test: TestItem,
    val isCompleted: Boolean = false
)

data class TestScoreResult(
    val testTitle: String,
    val totalQuestions: Int,
    val correctAnswersCount: Int,
    val obtainedMarks: Int,
    val totalPossibleMarks: Int
)
